/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Game.hpp"
#include "Cell.hpp"

#include <stdlib.h>
#include <iostream>
#include <valarray>
using namespace std;
Game::Game() {
    cout<<"Please enter board size: "<<endl;
    cin>>size;;
    cout<<"Please enter total number of players: "<<endl;
    cin>>numPlayers;
    cout<<"Please enter number of computer players: "<<endl;
    cin>>compplayers;
    numPlayers+=compplayers;
    turn = 0;
    won = false;
    boardFull=false;
    makeBoard();
    getPlayers();
    printPlayers();
    printBoard();
    playGame();
    
    
// for non-automatized version – asks for board size, num players, num of computer players, and then initializes
// everything
// your code goes here
}
Game::Game(bool b) {
    if (b == true){
        size = rand() % 11 +3;
        numPlayers = 2;
        compplayers = 2;
        makeBoard();
        boardFull=false;
        turn = 0;
        won = false;
        getPlayers();
        printPlayers();
        makeBoard();
        printBoard();
        playGame();
    }
    else{
        Game();
    }
    
//for the automated version – if b is true, randomly generate the size of the board, set the num of players and the
//num of compplayers to 2, and the, of course initialize everything
// your code goes here
}
void Game::makeBoard(){
    //dynamically create board to be size x size
    board = new char*[size];
    for (int i = 0; i < size; i++) {
        board[i] = new char[size];
        for (int j = 0; j < size; j++) {
            board[i][j] = '.';
        }
    }
}
void Game::printBoard() {
//Note: I’m giving you this one
 for (int i = 0; i < size; i++) {
 for (int j = 0; j < size; j++) {
 cout << board[i][j]<<"\t";
 }
 cout << endl;
 }
}
void Game::getPlayers() {
//This method dynamically generates an array of players, and then, for each element in the array, creates a new
//player object with a name and a character. For the number of players that are computers, I used an array of names
// and an array of characters, and then just selected the next name and character in the list for my player object.
// for humans I called the Player constructor with no input parameters (that one asked the user for their name and
// their preferred character.
// your code goes here
    //create string array for names of computer players
    
    string compNames[] = {"George", "Sally", "Bob","Kelly", "Ryan"};
    char compCharacters[]={'a','b','c','d','e'};
    int NumCompPlayers = compplayers;
    players = NULL;
    players = new Player*[numPlayers];
    for (int i = 0; i< numPlayers;i++){
        if (NumCompPlayers>0){
            players[i] = new Player (compNames[i], compCharacters[i], true);
            NumCompPlayers--;
        }
        else{
            players[i] = new Player();
        }
    }
}
void Game::printPlayers() {
// this method is optional – I wrote it so I could test my getPlayers() method to make sure it generated all my Players
// correctly. If you choose not to include this method, that is fine.
    for (int i = 0; i<numPlayers;i++){
        cout<<"Players"<<(*players[i]).name<<endl;
    }
}
void Game::playGame() {
// This is the heart of the game. I called this method directly from my Game constructor(s) as the very last thing.
//This method loops until the board is full.
// In each loop, the next player either chooses where to place their character (if human) or the x,y coordinates are
// randomly generated (and checked to make sure the player isn’t overwriting a piece already on the board).
//It checks to see if the new piece completes a square, and, if so, that player’s score goes up by 1 and that player
// takes another turn. At the end of each round, the board is printed out and each player’s name and score is printed.
//Your code goes here
boardFull = false;//makes sure board is empty
    getPlayers(); //gets players for game
    int x;
    int y;
    while (boardFull == false){
        //boardFull = true;
        for (int i = 0; i<numPlayers;i++){
            //if player is human, ask to input coordinates
            if ((*players[i]).isComputer == false){
            cout<<"Please enter x coordinate on board"<<endl;
            cin>>x;
            cout<<"Please enter y coordinate on board"<<endl;
            cin>>y;
            while(checkFour(x,y)){
                (*players[i]).score++;
            }
            }
            //if player is computer, generate random coordinates
            if((*players[i]).isComputer == true){
                x = rand() % size;
                y = rand() % size;
                while(findMoves((*players[i]).c)){
                (*players[i]).score++;
            }
            }
            
        }
        printBoard();//prints board after each round
        for (int i = 0; i<numPlayers; i++){
            cout<<"Players Name: "<<(*players[i]).name<<"Score = "<<(*players[i]).score<<endl;
        }
        for(int i = 0; i < numPlayers; i++){
            for(int j = 0; j< size; j++){
                if (board[i][j] == '.'){
                    boardFull = false;
                    break;
                }
            }
        }
    }
    
}

bool Game::findMoves(char v){
    int index; //index of player who's turn it currently is
    bool placed = false;
    for (int i; i<numPlayers; i++){
        if ((*players[i]).c = v){
            index = i;//sets index to the index of current player
        }
    }
    while (boardFull != true){
        //create random x and y values
        int x = rand() % size;
        int y = rand() % size;
        //if cell at (x,y) is empty, put char v there
        for(int i = 0; i<size; i++){
            for (int j=0; j<size;j++){
                if (board[i][j] == '.'){
                    board[i][j]=v;
                    //if creates a square, score increases
                    placed = true;
                    if (checkFour(x,y)){
                        (*players[index]).score++;
                        findMoves(v);
                    }
                    //else, turn goes to next player
                    else{
                        break;
                    }                  
                    
                }
                //create new x and y
                else{
                    x = rand() % size;
                    y = rand() % size;
                }
            }
            if (placed == false){
                for (int i = 0; i<size; i++){
                    for (int j = 0; j <size; j++){
                        if(board[x][y]=='.'){
                            board[x][y] = v;
                            placed = true;
                            if(checkFour (x, y)){
                                (*players[index]).score++;
                                findMoves(v);
                            }
                            else{
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
  
    
    
    
    
// Regular version, this method continues to generate random x,y values until that cell on the
// board is empty, then places the player's character v on the board, and checks to see if a
// square is completed using checkFour. If so, true is returned and that player’s score goes up by 1 in the
// playGame method, and that player gets to take another turn (so turn does not increase by 1).
// This method uses checkFour() method to determine whether a move is good, checkThree to determine if a move is
// bad, and if neither of those is true, then the move is considered neutral.
// This method returns the list of three movesList objects.
}
bool Game::checkFour(int x, int y) {
    for (int i = 0; i<size; i++){
        for (int j = 0; j<size; j++){
            if (board[x+1][y] != '.' && board[x][y-1] != '.' && board[x+1][y-1] != '.'){
                return true;
            }
            
            else if(board[x+1][y] != '.' && board[x][y+1] != '.' && board[x+1][y+1] != '.'){
                return true;
            }
            else if(board[x-1][y] != '.' && board[x][y+1]!= '.' && board[x-1][y+1] != '.'){
                return true;
            }
            else if(board[x-1][y] != '.' && board[x][y-1] != '.' && board[x-1][y-1] != '.'){
                return true;
            }
        //makes a square if character on board at following locations:
        //(x+1,y)(x,y-1)(x+1,y-1)
        //OR
        //(x+1,y)(x,y+1)(x+1,y+1)
        //OR
        //(x-1,y)(x,y+1)(x-1,y-1)
        //OR
        //(x-1,y)(x,y-1)(x-1,y-1)
          
    
            else{
                return false;
            }
// this method checks to see if placing a piece at x and y on the board will complete a square, and, if so, it
// returns true. Otherwise it returns false.
        }
    }
}
void Game::getWinner() {
// This method determines which of the players in the array of Players has the highest score, and prints out 
// that player’s name and their score.
    int BestScore = -1;
    string winner;
    for (int i = 0; i<numPlayers; i++){
        if ((*players[i]).score>BestScore){
            BestScore = (*players[i]).score;
            winner = (*players[i]).name;
        }
    }
    cout<<"Winner = "<<winner<<"Best Score is: "<<BestScore<<endl;
}
//bool Game::checkThree(int x, int y) {
//// Only needed for Extra Credit
//// This method determines whether placing a piece on the board at x and y will complete ¾ of a square and, if so, it
//// returns true. Otherwise it returns false.
//}
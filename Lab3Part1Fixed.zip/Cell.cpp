/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "cell.hpp"
cell::cell(){ //initializes x and y to -1 (not on board)
}
cell::cell(int a, int b){ // initializes x to a and y to b
}
void cell::resetCell(int a, int b) { // resets x to a and y to b
}